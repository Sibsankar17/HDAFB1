
employeeWage<-function(){
  
  library(readxl)
 
  
  #-------------------problem 1-------------
  for(i in 1:3){
    Sheet<- paste("Sheet",i,sep="")
    print(paste("-----------------Problee",i,"------------"),sep="")
    p1 <-read_excel("Employee Wage Comparision_Question.xlsx", sheet = Sheet)
    p1$Gender<- as.factor(p1$Gender)
    p1$Company<-as.factor(p1$Company)
    model1<- lm(Salary ~ Company*Gender,data=p1)
    print(anova(model1))
    }
  }
